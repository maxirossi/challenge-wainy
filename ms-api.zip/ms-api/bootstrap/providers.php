<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\RouteServiceProvider::class,
    App\Modules\Deudores\Providers\DeudoresServiceProvider::class,
];
