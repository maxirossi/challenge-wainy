<?php

namespace App\Modules\Deudores\ValueObjects; 