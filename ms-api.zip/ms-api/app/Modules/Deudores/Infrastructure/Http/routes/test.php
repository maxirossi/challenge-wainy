<?php

use Illuminate\Support\Facades\Route;

Route::get('/test-deudores', function () {
    return response()->json(['message' => 'Test deudores OK']);
}); 