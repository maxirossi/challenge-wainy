<?php

use Illuminate\Support\Facades\Route;
use App\Modules\Deudores\Infrastructure\Http\Controllers\DeudorController;

// Rutas para el dominio Deudores
Route::prefix('deudores')->group(function () {
    Route::get('/{cuit}', [DeudorController::class, 'show']);
    Route::get('/top/{n}', [DeudorController::class, 'top']);
    Route::post('/process-sqs', [DeudorController::class, 'processSqsMessages']);
}); 