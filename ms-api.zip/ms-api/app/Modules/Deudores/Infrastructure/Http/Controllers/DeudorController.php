<?php

namespace App\Modules\Deudores\Infrastructure\Http\Controllers;

use App\Application\UseCases\Deudores\GetDeudorByCuitUseCase;
use App\Application\UseCases\Deudores\GetTopDeudoresUseCase;
use App\Application\UseCases\Deudores\GetDeudoresByEntidadUseCase;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use InvalidArgumentException;

class DeudorController extends Controller
{
    public function __construct(
        private GetDeudorByCuitUseCase $getDeudorByCuitUseCase,
        private GetTopDeudoresUseCase $getTopDeudoresUseCase,
        private GetDeudoresByEntidadUseCase $getDeudoresByEntidadUseCase
    ) {}

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Obtiene el resumen de un deudor por CUIT
     */
    public function show(string $cuit): JsonResponse
    {
        try {
            $resumen = $this->getDeudorByCuitUseCase->execute($cuit);
            
            return response()->json([
                'success' => true,
                'data' => $resumen
            ]);
        } catch (InvalidArgumentException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error interno del servidor'
            ], 500);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    /**
     * Obtiene los deudores por entidad financiera
     */
    public function byEntidad(string $codigo): JsonResponse
    {
        try {
            $resumen = $this->getDeudoresByEntidadUseCase->execute($codigo);
            return response()->json([
                'success' => true,
                'data' => $resumen
            ]);
        } catch (InvalidArgumentException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error interno del servidor'
            ], 500);
        }
    }

    /**
     * Obtiene los top N deudores con mayor deuda (opcional: filtro por situación)
     */
    public function top(Request $request, int $n): JsonResponse
    {
        try {
            $situacion = $request->query('situacion');
            $deudores = $this->getTopDeudoresUseCase->execute($n, $situacion);
            return response()->json([
                'success' => true,
                'data' => $deudores
            ]);
        } catch (InvalidArgumentException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error interno del servidor'
            ], 500);
        }
    }

    /**
     * Endpoint temporal para procesar mensajes SQS manualmente
     */
    public function processSqsMessages(): JsonResponse
    {
        try {
            // Simular el mensaje que viene de ms-importer
            $messageData = [
                'deudores' => [
                    [
                        'cuit' => '20-00390552-8',
                        'codigo_entidad' => 'BANCO001',
                        'tipo_deuda' => 'préstamo personal',
                        'monto_deuda' => 150000.00,
                        'situacion' => 'normal',
                        'fecha_vencimiento' => '2024-12-31',
                        'fecha_procesamiento' => '2024-01-01T00:00:00Z',
                        'nombre_entidad' => 'Banco de la Nación Argentina',
                        'tipo_entidad' => 'banco'
                    ]
                ]
            ];

            // Despachar el Job
            \App\Jobs\ProcessSqsMessage::dispatch($messageData);

            return response()->json([
                'success' => true,
                'message' => 'Job despachado correctamente',
                'data' => $messageData
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ], 500);
        }
    }
}
