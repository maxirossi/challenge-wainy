<?php

namespace App\Modules\Deudores\Providers;

use Illuminate\Support\ServiceProvider;
use App\Modules\Deudores\Repositories\DeudorRepositoryInterface;
use App\Infrastructure\Persistence\Eloquent\Repositories\EloquentDeudorRepository;

class DeudoresServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(DeudorRepositoryInterface::class, EloquentDeudorRepository::class);
    }

    public function boot()
    {
        // Cargar rutas directamente en lugar de usar loadRoutesFrom
        \Illuminate\Support\Facades\Route::prefix('deudores')->group(function () {
            \Illuminate\Support\Facades\Route::get('/{cuit}', [\App\Modules\Deudores\Infrastructure\Http\Controllers\DeudorController::class, 'show']);
            \Illuminate\Support\Facades\Route::get('/top/{n}', [\App\Modules\Deudores\Infrastructure\Http\Controllers\DeudorController::class, 'top']);
            \Illuminate\Support\Facades\Route::post('/process-sqs', [\App\Modules\Deudores\Infrastructure\Http\Controllers\DeudorController::class, 'processSqsMessages']);
        });
    }
} 